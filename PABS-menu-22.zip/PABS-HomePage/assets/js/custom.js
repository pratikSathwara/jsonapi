/* Scroll Down Start  */
$(document).ready(function(){
  $(".ct-btn-scroll").on('click', function(event) {
    if (this.hash !== "") {
      event.preventDefault();
      var hash = this.hash;
      $('html, body').animate({
        scrollTop: $(hash).offset().top
      }, 800, function(){
        window.location.hash = hash;
      });
    } 
  });

$('#homeslider').owlCarousel({
    loop:true,
    autoplay:true,
    items:1
});
});



$(document).ready(function(){
  
	// SLIDER
	//$('.slider').slick({});
		
  $('.HomeBanner').slick({
    dots: true,
    speed: 1000,
    infinite: true,
    autoplay: true,
    autoplaySpeed: 3000,
    nextArrow: false,
    prevArrow: false,
  });
  $('.client').slick({
    dots: true,
    speed: 1000,
    infinite: true,
    // autoplay: true,
    autoplaySpeed: 3000,
    nextArrow: false,
    prevArrow: false,
  });
  $('.service').slick({
    slidesToShow: 5,
    slidesToScroll: 1,
    centerMode: true,
    arrows: true,
    dots: false,
    speed: 500,
    infinite: true,
    autoplaySpeed: 5000,
    // autoplay: true,
    nextArrow: '<div class="slick-custom-arrow slick-custom-arrow-right"><img src="/assets/image/next-grey.png" alt=""></div>',
    prevArrow: '<div class="slick-custom-arrow slick-custom-arrow-left"><img src="/assets/image/prev-grey.png" alt=""></div>',
              responsive: [                        
              {
                breakpoint: 576,settings: {
                slidesToShow: 1,centerMode: true}
              },
              {
                breakpoint: 991,settings: {
                slidesToShow: 2,centerMode: true}
              },
              {
                breakpoint: 1100,settings: {
                slidesToShow: 3,centerMode: true}
              },
          ]
  });
});

$('.center').slick({
centerMode: true,
centerPadding: '60px',
slidesToShow: 3,
responsive: [
{
breakpoint: 768,
settings: {
arrows: false,
centerMode: true,
centerPadding: '40px',
slidesToShow: 3
}
},
{
breakpoint: 480,
settings: {
arrows: false,
centerMode: true,
centerPadding: '40px',
slidesToShow: 1
}
}
]
});

$('.insights-slider').slick({
  dots: true,
  speed: 1000,
  infinite: true,
  // autoplay: true,
  autoplaySpeed: 3000,
  nextArrow: false,
  prevArrow: false,
});
         
$('input,textarea').val("");
$('.form-group input, .form-group textarea').focusout(function() {
  var text_val = $(this).val();
  if (text_val === "") {
    console.log("empty!");
    $(this).removeClass('has-value');
  } else {
    $(this).addClass('has-value');
  }
});



window.onscroll = function() {scrollFunction()};

function scrollFunction() {
  if (document.body.scrollTop > 20 || document.documentElement.scrollTop > 20) {
    document.getElementById("scroll_btn").style.display = "block";
  } else {
    document.getElementById("scroll_btn").style.display = "none";
  }
}
// When the user clicks on the button, scroll to the top of the document
$(document).ready(function() {
    $("#scroll_btn").click(function(event) {
        event.preventDefault();
        $("html, body").animate({ scrollTop: 0 }, "slow");
        return false;
    });

});

